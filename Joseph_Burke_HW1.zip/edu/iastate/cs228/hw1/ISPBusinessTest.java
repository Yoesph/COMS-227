package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Testing every method in ISPBusiness class besides main method. Main method does not modify anything by itself and only calls
 * other methods and finally spits out a profit utilization string
 *
 */
class ISPBusinessTest {
	
	private Town town= null;

	@Test
	void testUpdatePlain() {
		
		//open given example grid
		try {
			town = new Town("src/ISP4x4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//update it to 1st iteration
		town = ISPBusiness.updatePlain(town);
		
		//put grid in a string (See town class) for method
		String townStr = town.toString();
		
		//homework write up gives all iterations of this grid over a year so we know this 
		//is the grid after one
		assertEquals("E E E E \n" + "C C O E \n" + "C O E O \n" + "C E E E \n",townStr);
	}
	
	@Test
	void testGetProfit() {
		
		//open given example grid
		try {
			town = new Town("src/ISP4x4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//profit is calculated by $1 per casual grid
		int profit = ISPBusiness.getProfit(town);
		
		assertEquals(1,profit);
	}
}
