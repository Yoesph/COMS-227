package edu.iastate.cs228.hw1;

/**
 * 
 * @author Joseph Burke
 * Represents a cell with a network outage and contains the rules to update the cell each iteration
 *
 */

public class Outage extends TownCell{

	public Outage(Town p, int r, int c) {
		//calls parent constructor
		super(p, r, c);
	}

	/**
	 * Identifies the TownCell type and returns it
	 * @return State
	 */
	@Override
	public State who() {
		return State.OUTAGE;
	}

	/**
	 * In outage's case this method need not call census and will become an empty cell regardless of its neighbors.
	 * @param tNew: town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		
		return new Empty(tNew, row, col);
	}

}
