package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Tests Streamer's methods to ensure they're working correctly
 *
 */
class StreamerTest {

	private Town town = null;

	@Test
	void testWho() {
		
		//set town equal to a grid exclusively full of Streamer towncells
		try {
			town = new Town("src/StreamerTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(State.STREAMER, town.grid[1][1].who());
		
	}
	
	@Test
	void testNext() {
		
		TownCell townCell = null;
		
		//no outage or empty cells so should convert to reseller
		try {
			town = new Town("src/StreamerTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.RESELLER,townCell.who());
		
		//grid with reseller, and more than one outage + empty as a neighbor should convert to empty
		try {
			town = new Town("src/StreamerTestGrid2.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.OUTAGE,townCell.who());
		
		//grid with reseller replaced with outage, should convert to empty
		try {
			town = new Town("src/StreamerTestGrid3.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.EMPTY,townCell.who());
		
		//grid with 5 casual cells, should stay Streamer
		try {
			town = new Town("src/StreamerTestGrid4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.STREAMER,townCell.who());
		
		//grid that does not follow any of the rules
		try {
			town = new Town("src/StreamerTestGrid5.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.STREAMER,townCell.who());
	}

}
