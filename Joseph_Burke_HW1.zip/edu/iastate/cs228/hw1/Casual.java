package edu.iastate.cs228.hw1;

/**
 * 
 * @author Joseph Burke
 * Class represents a Casual network user that resides in a particular neighborhood, also 
 * contains the rules to update the cell each iteration
 *
 */

public class Casual extends TownCell{

	public Casual(Town p, int r, int c) {
		//constructor that calls parent constructor
		super(p, r, c);
	}
	
	/**
	 * Identifies the TownCell type and returns it
	 * @return State
	 */
	@Override
	public State who() {
		return State.CASUAL;
	}
	
	/**
	 * This method will need to read the neighboring cells using TownCell's census method
	 * and then follow the guidelines given on how it should change
	 * @param tNew: Town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		
		//Call census to populate the nCensus array with the counts of each TownCell type
		census(nCensus);
		
		//is not a reseller or an outage, so # of empty cells and # of outage cells are added.
		//if <= 1 convert to reseller
		if (nCensus[1] + nCensus[3] <= 1) {
			return new Reseller(tNew,row,col);
		}
		
		//if a reseller is a neighbor change cell to an outage cell
		else if (nCensus[0] > 0) {
			return new Outage(tNew, row, col);
		}
		
		//if streamer is a neighbor casual user becomes a streamer
		else if (nCensus[4] > 0) {
			return new Streamer(tNew,row,col);
		}
		
		//if 5 or more casual neighbors become streamer
		else if (nCensus[2] >= 5) {
			return new Streamer(tNew,row,col);
		}
		//if no rules proc then keep as casual
		else {
			return new Casual(tNew,row,col);
		}
	}
}
