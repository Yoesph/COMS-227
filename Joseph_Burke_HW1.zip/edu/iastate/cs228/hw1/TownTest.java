package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Tests all the methods in the Town class to ensure function
 *
 */

class TownTest {
	
	private Town town = null;

	@Test
	void testGetWidth() {
		
		try {
			town = new Town("src/Test20x20.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(22,town.getWidth());
	}
	
	@Test
	void testGetLength() {
		
		try {
			town = new Town("src/Test20x20.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(20,town.getLength());
	}
	
	@Test
	void testtoString() {
		
		try {
			town = new Town("src/ISP4x4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		String townStr = town.toString();
		
		assertEquals("O R O R \n" + "E E C O \n" + "E S O S \n" + "E O R R \n", townStr);
	}
	
	@Test
	void testRandomInit() {
		town = new Town(3,5);
		town.randomInit(999999999);
		
		String townStr = town.toString();
		
		assertEquals("R C S C E \n" + "C S S S S \n" + "O R S E S \n" , townStr);
	}

}
