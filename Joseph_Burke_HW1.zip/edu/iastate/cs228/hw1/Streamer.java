package edu.iastate.cs228.hw1;

/**
 * 
 * @author Joseph Burke
 * Represents a Streamer in a neighborhood network. Contains the rules to update it each iteration
 *
 */

public class Streamer extends TownCell{

	public Streamer(Town p, int r, int c) {
		//calls parent constructor
		super(p, r, c);
	}
	
	/**
	 * Identifies the TownCell type and returns it
	 * @return State
	 */
	@Override
	public State who() {
		return State.STREAMER;
	}

	/**
	 * This method will need to read the neighboring cells using TownCell's census method
	 * and then follow the guidelines given on how it should change
	 * @param tNew: Town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		
		//Call census to populate the nCensus array with the counts of each TownCell type
		census(nCensus);
		
		//is not a reseller or an outage, so # of empty cells and # of outage cells are added.
		//if <= 1 convert to reseller
		if (nCensus[1] + nCensus[3] <= 1) {
			return new Reseller(tNew,row,col);
		}
				
		//if a reseller is a neighbor change cell to an outage cell
		else if (nCensus[0] > 0) {
			return new Outage(tNew, row, col);
		}
		
		//if there's an outage in the neighborhood the streamer leaves and cell becomes empty
		else if (nCensus[3] > 0) {
			return new Empty(tNew, row, col);
		}
		
		//if there are 5 or more casual neighbors it stays a streamer -- probably redundant, but keeping
		else if (nCensus[2] >= 5) {
			return new Streamer(tNew,row,col);
		}
		
		//if all rules fail to proc stays streamer
		else {
			return new Streamer(tNew,row,col);
		}
		
	}
}
