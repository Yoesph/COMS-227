package edu.iastate.cs228.hw1;

/**
 * 
 * @author Joseph Burke
 * Represents a Reseller in a neighborhood network. Contains the rules to update the cell each iteration
 */

public class Reseller extends TownCell{

	public Reseller(Town p, int r, int c) {
		//calls parent constructor
		super(p, r, c);
	}

	/**
	 * Identifies the TownCell type and returns it
	 * @return State
	 */
	@Override
	public State who() {
		return State.RESELLER;
	}

	/**
	 * This method will need to read the neighboring cells using TownCell's census method
	 * and then follow the guidelines given on how it should change
	 * @param tNew: Town of the next cycle
	 * @return TownCell
	 */
	@Override
	public TownCell next(Town tNew) {
		
		//Call census to populate the nCensus array with the counts of each TownCell type
		census(nCensus);
		
		//if there are 3 or less casual cells neighboring this cell it becomes empty
		if (nCensus[2] <= 3) {
			return new Empty(tNew, row, col);
		}
		
		//if there are 3 or more empty cells this cell becomes empty
		else if (nCensus[1] >= 3) {
			return new Empty(tNew, row, col);
		}
		
		//cell that has 5 or more casual neighbors becomes a streamer
		else if (nCensus[2] >= 5) {
			return new Streamer(tNew,row,col);
		}
		
		//if no rules proc stays a reseller
		else {
			return new Reseller(tNew,row,col);
		}
	}
}
