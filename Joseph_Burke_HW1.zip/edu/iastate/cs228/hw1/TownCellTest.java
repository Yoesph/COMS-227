package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Tests the methods in the TownCell class. Namely the census class
 *
 */

class TownCellTest {
	
	private Town town = null;
	//private TownCell townCell = null;

	@Test
	void testCensus() {
		
		try {
			town = new Town("src/Test20x20.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//taking the point at row 13 col 15 and counting the types of neighbors
		town.grid[13][15].census(TownCell.nCensus);
		
		//five different types of towncell counted. Check towncell class to see what each index is equal to
		assertEquals(2,TownCell.nCensus[0]);
		assertEquals(1,TownCell.nCensus[1]);
		assertEquals(2,TownCell.nCensus[2]);
		assertEquals(2,TownCell.nCensus[3]);
		assertEquals(1,TownCell.nCensus[4]);
		
	}

}
