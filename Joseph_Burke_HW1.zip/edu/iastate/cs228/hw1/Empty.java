package edu.iastate.cs228.hw1;

/**
 * 
 * @author Joseph Burke
 * Class represents an empty cell in a neighborhood i.e. one with no one living there. Contains the rules to 
 * update the cell with every iteration
 */

public class Empty extends TownCell{

	public Empty(Town p, int r, int c) {
		//calls parent
		super(p, r, c);
	}

	/**
	 * Identifies the TownCell type and returns it
	 * @return State
	 */
	@Override
	public State who() {
		return State.EMPTY;
	}

	/**
	 * Figures out what empty cell will be next cycle. checks additional rule first then if that fails
	 * becomes a casual cell
	 */
	@Override
	public TownCell next(Town tNew) {
		
		//call census to populate the array. only needed for the additional rules
		census(nCensus);
		
		//is not a reseller or an outage, so # of empty cells and # of outage cells are added.
		//if <= 1 convert to reseller
		if (nCensus[1] + nCensus[3] <= 1) {
			return new Reseller(tNew,row,col);
		}
		
		//becomes a casual cell if above rule doesn't overwrite it
		else {
			return new Casual(tNew,row,col);
		}
		
	}

}
