package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Tests each of Reseller's methods to ensure they are working
 *
 */
class ResellerTest {

	private Town town = null;

	@Test
	void testWho() {
		
		//set town equal to a grid exclusively full of Reseller towncells
		try {
			town = new Town("src/ResellerTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(State.RESELLER, town.grid[1][1].who());
		
	}
	
	@Test
	void testNext() {
		
		TownCell townCell = null;
		
		//same grid since there are no casual cells nearby. Should bring us into first if statement changing the cell to empty
		try {
			town = new Town("src/ResellerTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.EMPTY, townCell.who());
		
		//grid with 4 casual cells and 3 empty cells to attempt to enter the 2nd if statement
		try {
			town = new Town("src/ResellerTestGrid2.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.EMPTY, townCell.who());
		
		//grid with 5 casual cells as neighbors
		try {
			town = new Town("src/ResellerTestGrid3.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.STREAMER, townCell.who());
		
		//grid that does not follow any rule and should cause else statement to execute
		try {
			town = new Town("src/ResellerTestGrid4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.RESELLER, townCell.who());
		
	}

}
