package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Tests each of Outage's methods to ensure they're working
 */

class OutageTest {

	private Town town = null;

	@Test
	void testWho() {
		
		//set town equal to a grid exclusively full of Outage towncells
		try {
			town = new Town("src/OutageTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(State.OUTAGE, town.grid[1][1].who());
		
	}
	
	@Test
	void test() {
		
		TownCell townCell = null;
		
		//set town equal to a grid exclusively full of Outage towncells because outage only has one possible rule
		try {
			town = new Town("src/OutageTestGrid.txt");
		} catch (FileNotFoundException e) {
					e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.EMPTY,townCell.who());
		
	}

}
