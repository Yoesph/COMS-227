package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Test class that vets Casual's methods
 */

class CasualTest {
	
	private Town town = null;

	@Test
	void testWho() {
		
		//set town equal to a grid exclusively full of Casual towncells
		try {
			town = new Town("src/CasualTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(State.CASUAL, town.grid[1][1].who());
		
	}
	
	@Test
	void testNext() {
		
		TownCell townCell = null;
		
		try {
			town = new Town("src/CasualTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//lands on a casual cell surrounded by casual cells testing the first if statement in the next method
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.RESELLER,townCell.who());
		
		//new grid with two added Empties and a reseller to prompt the second of statement
		try {
			town = new Town("src/CasualTestGrid2.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.OUTAGE,townCell.who());
		
		//grid with reseller switched to streamer for third if statement
		try {
			town = new Town("src/CasualTestGrid3.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.STREAMER,townCell.who());
		
		//grid with streamer swapped to empty to attempt to enter fourth if statement
		try {
			town = new Town("src/CasualTestGrid4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.STREAMER,townCell.who());
		
		//added extra outage cell to not follow any rule and remain a casual cell
		try {
			town = new Town("src/CasualTestGrid5.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.CASUAL,townCell.who());
	}

}
