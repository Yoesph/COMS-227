package edu.iastate.cs228.hw1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author Joseph Burke
 * Test class to vet both of Empty's methods
 */
class EmptyTest {
	
	private Town town = null;

	@Test
	void testWho() {
		
		//set town equal to a grid exclusively full of Empty towncells
		try {
			town = new Town("src/EmptyTestGrid.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		assertEquals(State.EMPTY, town.grid[1][1].who());
		
	}
	
	@Test
	void testNext() {
		
		TownCell townCell = null;
		
		//grid with no other empty or outage cells. Attempting to go into if statement
		try {
			town = new Town("src/EmptyTestGrid2.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.RESELLER,townCell.who());
		
		//grid with two added outage cells to attempt to enter else statement
		try {
			town = new Town("src/EmptyTestGrid3.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		townCell = town.grid[1][1].next(town);
		
		assertEquals(State.CASUAL,townCell.who());
	}

}
