package edu.iastate.cs228.hw3;

/**
 * This class is used to assign an operator a stack Precedence, mainly here to make convertIn2Post less messy and easier to understand
 * @author Joseph Burke
 *
 */
public class StackPrecedence {
	private char op;
	
	public StackPrecedence(char op){
		this.op = op;
	}
	
	public int assignPrecedence() {
		int stackPre = 0;
		
		if (op == '+' || op == '-' || op == '�') {
			stackPre = 1;
		}
		
		else if (op == '*' || op == '/' || op == '%') {
			stackPre = 2;
		}
		
		else if (op == '^') {
			stackPre = 3;
		}
		
		else if (op == '(') {
			stackPre = -1;
		}
		
		else if (op == ')') {
			stackPre = 0;
		}
		return stackPre;
	}

}
