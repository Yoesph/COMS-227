package edu.iastate.cs228.hw3;
/**
 * This is used to assign an operator an input precedence. Here mainly to make ConvertIn2Post less messy and easier to understand
 * @author Joseph Burke
 *
 */
public class InputPrecedence {
	
	private char op;
	
	public InputPrecedence(char op) {
		this.op = op;
	}
	
	public int assignPrecedence() {
		
		int inputPre = 0;
		
		if (op == '+' || op == '-' || op == '�') {
			inputPre = 1;
		}
		
		else if (op == '*' || op == '/' || op == '%') {
			inputPre = 2;
		}
		
		else if (op == '^') {
			inputPre = 4;
		}
		
		else if (op == '(') {
			inputPre = 5;
		}
		
		else if (op == ')') {
			inputPre = 0;
		}
		
		return inputPre;
	}

}
