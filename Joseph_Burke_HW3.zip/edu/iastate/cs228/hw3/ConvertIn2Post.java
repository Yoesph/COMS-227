package edu.iastate.cs228.hw3;

import java.util.Scanner;
import java.util.Stack;

/**
 * This class is responsible for converting the Infix equation to PostFix, and for error detecting
 * @author Joseph Burke
 *
 */
public class ConvertIn2Post {
	
	private int cumulRank = 0;
	private String inLine= "";
	private String postLine = "";
	private char next;
	private char nextPrev;
	private int nextNum;
	private int count = 0;
	Stack<Character> stack = new Stack<Character>();
	
	/**
	 * constructor to read in a line of the equation
	 * @param inLine the particular line of the input file we are working with
	 */
	public ConvertIn2Post(String inLine) {
		this.inLine = inLine;
	}
	
	/**
	 * The purpose of this method is to do the conversion between the two types and spit out errors if a problem occurs
	 * @return
	 */
	public String convert() {
		
		Scanner scan = new Scanner(inLine);
		
		//iterate through the string
		while (scan.hasNext()) {
			
			//if cumulRank drops below 0 it means were are missing an operand, or in other words too many operators
			if (cumulRank < 0) {
				scan.close();
				return "Error: too many operators (" + next + ")";
			}
			
			//similar to before but with operands
			if (cumulRank > 1) {
				scan.close();
				return "Error: too many operands (" + nextNum + ")";
			}
			
			//if the current character is an operand write to output, and add one to cumulRank.
			//also set nextNum for error checking
			if (scan.hasNextInt()) {
				nextNum = scan.nextInt();
				postLine += nextNum + " ";
				cumulRank++;
				continue;
			}
			
			//delays this assignment by one so this will be one behind the next variable.
			//Only needed for error checking empty ()
			if (count > 0) {
				nextPrev = next;
			}
			
			//increment count
			count++;
			
			//take the next operator that the scanner has, and get the character value from it
			String nextString = scan.next();
			next = nextString.charAt(0);
			
			//if the operator is anything besides () we throw it into outputHigherOrEqual 
			//and adjust cumulRank (includes both '�' and '-' 
			//because it seems some examples use the two interchangeably)
			if (next == '+' || next == '-' || next == '�' ||
					next == '*' || next == '/' || 
					next == '%' || next == '^') {
				outputHigherOrEqual(next);
				cumulRank--;
				continue;
			}
			
			//if the op is ( just throw it into the stack
			if (next == '(') {
				stack.push(next);
				continue;
			}
			
			//if the op is ) pop the stack until we reach a (, or the stack is empty
			//Also detects empty parenthesis
			if (next == ')') {
				
				if (nextPrev == '(') {
					scan.close();
					return "Error: no subexpression detected ()";
				}
				
				while (!stack.empty() && stack.peek() != '(') {
					postLine += stack.pop() + " ";
				}
				
				if (!stack.empty() && stack.peek() == '(') {
					stack.pop();
				}
				
				else {
					scan.close();
					return "Error: no opening parenthesis detected";
				}
				continue;
			}
			
			//technically not needed based on project description, but easy to implement so why not
			else {
				scan.close();
				return "Error: Invalid character (" + next + ")";
			}
		}
		
		//if cumulRank drops below 0 it means were are missing an operand, or in other words too many operators
		//this is a final check needed just in case cumulRank changes on the last iteration and exits the loop
		//before it can check
		if (cumulRank < 0) {
			scan.close();
			return "Error: too many operators (" + next + ")";
		}
		//similar to before but with operands
		if (cumulRank > 1) {
			scan.close();
			return "Error: too many operands (" + nextNum + ")";
		}
		
		scan.close();
		
		//after running everything just add whatever's left
		while (!stack.empty()) {
			
			if (stack.peek() == '(') {
				return "Error: no closing parenthesis detected";
			}
			
			postLine += stack.pop() + " ";
		}
		
		return postLine;
	}
	
	/**
	 * Using input and Stack precedence decides whether to add an operator to the stack first, or pop the stack.
	 * @param op operator being compared to the top of the stack
	 */
	public void outputHigherOrEqual(char op) {
		
		if (stack.empty()) {
			stack.push(op);
		}
		
		else {
			//assign the input precedence of the current operator and the stack precedence of the top of the stack
			InputPrecedence inputPres = new InputPrecedence(op);
			int inputPre = inputPres.assignPrecedence();
			StackPrecedence stackPres = new StackPrecedence(stack.peek());
			int stackPre = stackPres.assignPrecedence();
			
			//compares input precedence of op and stack precedence of the top of the stack.
			//This determines whether or not to simply add op to the stack,
			//or pop operators of lower, or equal precedence of op, until we reach an operator in which this isn't true
			if (inputPre > stackPre || stack.peek() == '(') {
				stack.push(op);
			}
			else {
				while (stackPre >= inputPre && (stack.peek() != '(' || stack.peek() != ')')) {
					postLine += stack.pop() + " ";
					
					if (!stack.empty()) {
						stackPres = new StackPrecedence(stack.peek());
						stackPre = stackPres.assignPrecedence();
					}
					else break;
				}
				stack.push(op);
			}
		}
	}
}
