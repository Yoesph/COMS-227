package edu.iastate.cs228.hw3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
 * Main method where the Infix to postFix conversion occurs. This is where the input file is read and output file is created.
 * @author Joseph Burke
 *
 */
public class Infix2Postfix {
	
	public static void main(String[] args) {
		
		//string that will be written to the output file
		String postFix = "";
		
		//read in the file. This assumes the file is read from the package directory, which I assume is what is meant by default directory
		File input = new File("input.txt");
		
		try {
			//assign the file to a scanner to have access to line by line reading
			Scanner scnr= new Scanner(input);
			
			//check for another line of Infix, then call "Method" to convert to Post fix and add to string
			while (scnr.hasNextLine()) {
				
				//creates a ConverIn2Post object and calls the convert method that returns a string
				ConvertIn2Post working = new ConvertIn2Post(scnr.nextLine());
				String temp = working.convert();
				
				//adds postFix expression to output string
				postFix += temp;
				
				//checks to see if string ends with space and removes it if so
				if(postFix.endsWith(" "))
				{
				  postFix = postFix.substring(0,postFix.length() - 1);
				}
				
				//moves to a new line in preparation for next line of equation
				postFix += "\n";
			}
			
			scnr.close();
			
			//creates a new file named output.txt and prints the output string to it
			PrintWriter out = new PrintWriter("output.txt");
			out.print(postFix);
			out.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
