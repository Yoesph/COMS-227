package edu.iastate.cs228.hw4;
/**
 * @author Joseph Burke
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		//prompt user
		System.out.print("Please enter filename to decode: ");
		
		//reads user input
		Scanner input = new Scanner(System.in);
		String filename = input.nextLine();
		
		input.close();
		
		//reads in file based on user inputed name
		File inputFile = new File(filename);
		
		//string for the part responsible for creating the tree, and the part with the encoded message
		String tree = "";
		String message = "";
		
		try {
			int count = 0;
			//counts the number of lines
			Scanner scnr = new Scanner(inputFile);
			while(scnr.hasNextLine()) {
				count++;
				scnr.nextLine();
			}
			scnr.close();
			
			Scanner scnr1 = new Scanner(inputFile);
			
			//this assumes there is any amount of lines to construct the tree, and the final line is the encoded message
			for (int i = 0; i < count - 1; i++) {
				tree += scnr1.nextLine() + "\n";
			}
			
			//previous loop adds an extra newline at the end, this removes it
			if(tree.endsWith("\n"))
			{
				tree = tree.substring(0,tree.length() - 1);
			}
			
			//final line is assigned to message
			message = scnr1.nextLine();
			scnr1.close();
			
			//error detection
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//creates a Msgtree using the constructor that accepts strings
		MsgTree treeRoot = new MsgTree(tree);
		
		//table header and the call to printCodes
		System.out.println("Character  code\n-------------------------");
		MsgTree.printCodes(treeRoot, "");
		
		//Message header and call to decode
		System.out.println("MESSAGE:");
		treeRoot.decode(treeRoot, message);
		
		//all the numbers and calculations for statistics
		int numChars = treeRoot.numChar;
		int numBits = message.length();
		double avgBits = (numBits * 1.0) / (numChars * 1.0);
		double spaceSaving = ((1.0 - (numBits * 1.0) / (16.0 * numChars)) * 100.0);
		
		//printing and formatting for statistics, while rounding the double outputs to one decimal
		System.out.println("\nSTATISTICS:");
		System.out.println("Avg bits/char:          " + String.format("%.1f",avgBits));
		System.out.println("Total characters:       " + numChars);
		System.out.println("Space savings:          " + String.format("%.1f",spaceSaving) + "%");
	}

}
