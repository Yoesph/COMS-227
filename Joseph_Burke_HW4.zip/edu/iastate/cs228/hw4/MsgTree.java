package edu.iastate.cs228.hw4;

/**
 * 
 * @author Joseph Burke
 * this class is one node of a MsgTree, and contains methods to create an entire tree based on a string, and decode a binary message
 * using said tree. Can also print out the binary paths of every character in the tree
 */

public class MsgTree{
	
	public char payloadChar;
	public MsgTree left;
	public MsgTree right;
	
	//added for statistics
	public int numChar;
	
	/*Can use a static char idx to the tree string for recursive 
	solution, but it is not strictly necessary*/
	private static int staticCharIdx = 0;
	
	//Constructor building the tree from a string
	public MsgTree(String encodingString){
		
		//creates an empty MsgTree and calls build 
		MsgTree full = build(encodingString, this);
		
		//updates current tree with the full tree
		this.payloadChar = full.payloadChar;
		this.left = full.left;
		this.right = full.right;
	}
	
	//Constructor for a single node with null children
	public MsgTree(char payloadChar){
		this.payloadChar = payloadChar;
		left = null;
		right = null;
	}
	
	//method to print characters and their binary codes
	public static void printCodes(MsgTree root, String code){
		
		//if the current payloadChar isn't a '^' it needs to be printed, if statement for newline formating
		if (root.payloadChar != '^') {
			if (root.payloadChar == '\n') {
				System.out.print("   " + "\\n" + "      ");
			}
			else {
				System.out.print("   " + root.payloadChar + "       ");
			}
		}
		
		//if the root's left child isn't null go down that path by calling printCodes again with that left child and adding 0 to our code
		if (root.left != null) {
			printCodes(root.left, code + "0");
		}
			
		//same as above but with the right child, and adding 1 to our code
		if(root.right != null) {
			printCodes(root.right, code + "1");
		}
			
		else {
			
			//print the code of the character we've reached
			System.out.println(code);
		}
	}
	
	//decodes the message using the binary input given and prints the final message
	public void decode(MsgTree codes, String msg) {
		
		//keep track of where we are in the string
		int index = 0;
		
		//copy of the original binary tree at the root
		MsgTree originalCodes = codes;
		
		//while the index hasn't exceeded the string's length
		while (index < msg.length()) {
			
			//while the current codes isn't null and it's payload is '^', meaning its either the root node or an internal node
			while (codes != null && codes.payloadChar == '^') {
				
				//check to make sure index isn't out of bounds, and then get the character at index, if it is 0 go left, if 1 go right. 
				//also have to check to make sure the left or right child isn't null. After than increment index and set codes to the child
				if (index < msg.length() && msg.charAt(index) == '0' && codes.left != null) {
					codes = codes.left;
					index++;
				}
				if (index < msg.length() && msg.charAt(index) == '1' && codes.right != null) {
					codes = codes.right;
					index++;
				}
			}
			
			//print the character we've reached
			System.out.print(codes.payloadChar);
			
			//increment numChar for statistics
			numChar++;
			
			//bring us back to the root for the next encoded message
			codes = originalCodes;
		}
		
	}
	
	/**
	 * This is the recursive method that builds the binary tree
	 * @param encodingString the given string to build the tree from
	 * @param current the current MsgTree we are at
	 * @return returns current
	 */
	public MsgTree build(String encodingString, MsgTree current) {
		
		//if the encodingString is at a '^' character, create a new MsgTree object with null children
		if (encodingString.charAt(staticCharIdx) == '^') {
			current = new MsgTree('^');
		
			//if there is still characters in the string increment staticCharIdx and set current.left to a recursive call of build
			if(staticCharIdx < encodingString.length()) {
				staticCharIdx++;
				current.left = build(encodingString, current.left);
			}
			
			//same as last if statement but with current.right
			if(staticCharIdx < encodingString.length()) {
				staticCharIdx++;
				current.right = build(encodingString, current.right);
			}
		}
		
		//if the current node is not a '^' create a node with that character and null children
		else {
			current = new MsgTree(encodingString.charAt(staticCharIdx));
		}
		
		//return what was just created
		return current;
	}
	
}
