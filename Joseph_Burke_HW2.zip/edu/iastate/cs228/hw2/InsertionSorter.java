package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;


/**
 *  
 * @author Joseph Burke
 *
 */

/**
 * 
 * This class implements insertion sort.   
 *
 */

public class InsertionSorter extends AbstractSorter 
{
	// Other private instance variables if you need ... 
	
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 * 
	 * @param pts  
	 */
	public InsertionSorter(Point[] pts) 
	{
		super(pts);
		algorithm = "InsertionSort";
	}	

	
	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 */
	@Override 
	public void sort()
	{
		
		int j = 0;
		//assign temp with the point at i and set j to one index behind temp
		//entire for loop will increment through the array, and when finding a value that is smaller the the ones to the left of it
		//it will shift everything smaller than it to the right by one and slot it in the correct space
		for (int i = 1; i < points.length; i++) {
			Point temp = points[i];
			j = i - 1;
			
			//shift elements greater than temp one index up
			while (j > -1 && pointComparator.compare(points[j], temp) > 0) {
				points[j + 1] = points[j];
				--j;
			}
			//increment j by one and set temp to that index
			points[j + 1] = temp;
		}
	}		
}
