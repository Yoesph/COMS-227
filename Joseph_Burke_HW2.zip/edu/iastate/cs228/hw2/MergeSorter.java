package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Joseph Burke
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if needed
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super (pts);
		algorithm = "MergeSort";
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		mergeSortRec(points);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts) 
	{
		
		if (pts == null) {
			return;
		}
		
		if (pts.length > 1) {
			int mid = pts.length / 2;
			
			//create left side array and populate with points from pts[]
			Point[] left = new Point[mid];
			for (int i = 0; i < mid; i++) {
				left[i] = pts[i];
			}
			
			//create right side array and populate with points from pts[]
			Point[] right = new Point[pts.length - mid];
			for (int i = mid; i < pts.length; i++) {
				right[i - mid] = pts[i];
			}
			
			//recursion to reduce left and right array to size 1
			mergeSortRec(left);
			mergeSortRec(right);
			
			//variables to keep track of indexes of left, right, and pts
			int i = 0;
			int j = 0;
			int k = 0;
			
			//find the lower number between right and left and put it first in pts array
			while (i < left.length && j < right.length) {
				if(pointComparator.compare(left[i], right[j]) < 0) {
					pts[k] = left[i];
					i++;
				}
				else {
					pts[k] = right[j];
					j++;
				}
				k++;
			}
			
			//add any leftover numbers in left side
			while(i < left.length) {
				pts[k] = left[i];
				i++;
				k++;
			}
			
			//same as above but with right side
			while(j < right.length) {
				pts[k] = right[j];
				j++;
				k++;
			}
		}
	}
	
	// Other private methods if needed ...

}
