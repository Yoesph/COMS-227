package edu.iastate.cs228.hw2;

import java.io.File;

/**
 * 
 * @author Joseph Burke
 *
 */

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * 
 * This class sorts all the points in an array of 2D points to determine a reference point whose x and y 
 * coordinates are respectively the medians of the x and y coordinates of the original points. 
 * 
 * It records the employed sorting algorithm as well as the sorting time for comparison. 
 *
 */
public class PointScanner  
{
	private Point[] points; 
	
	private Point medianCoordinatePoint;  // point whose x and y coordinates are respectively the medians of 
	                                      // the x coordinates and y coordinates of those points in the array points[].
	private Algorithm sortingAlgorithm;    
	
		
	protected long scanTime; 	       // execution time in nanoseconds. 
	
	/**
	 * This constructor accepts an array of points and one of the four sorting algorithms as input. Copy 
	 * the points into the array points[].
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException
	{
		//throws exception if array is empty
		if (pts == null || pts.length == 0) {
			throw new IllegalArgumentException();
		}
		
		//populates class's Point array with given array
		else {
			points = new Point[pts.length];
			for (int i = 0; i < pts.length; i++) {
				points[i] = pts[i];
			}
			//sets sorting algorithm
			sortingAlgorithm = algo;
		}
	}

	
	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param  inputFileName
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException   if the input file contains an odd number of integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException
	{
		//both scanners read the given file, one for content, and one to count the number of integers
		Scanner input = new Scanner(new File(inputFileName));
		Scanner input1 = new Scanner(new File(inputFileName));
		
		int i = 0;
		int count = 0;
		
		//counts number of integers in the file
		while (input1.hasNextInt()) {
			input1.nextInt();
			count++;
		}
		
		//if the number of integers isn't even throw an exception
		if (count % 2 != 0) {
			throw new InputMismatchException();
		}
		
		//each point needs two integers so an array of points needs half the size
		points = new Point[count/2];
		
		//read the integers into x and y values
		while (input.hasNextLine()) {
			int x = input.nextInt();
			int y = input.nextInt();
			points[i] = new Point(x, y);
			i++;
		}
		input.close();
		input1.close();
		
		//set algorithm
		sortingAlgorithm = algo;
		
	}

	
	/**
	 * Carry out two rounds of sorting using the algorithm designated by sortingAlgorithm as follows:  
	 *    
	 *     a) Sort points[] by the x-coordinate to get the median x-coordinate. 
	 *     b) Sort points[] again by the y-coordinate to get the median y-coordinate.
	 *     c) Construct medianCoordinatePoint using the obtained median x- and y-coordinates.     
	 *  
	 * Based on the value of sortingAlgorithm, create an object of SelectionSorter, InsertionSorter, MergeSorter,
	 * or QuickSorter to carry out sorting.       
	 * @param algo
	 * @return
	 */
	public void scan()
	{
		
		AbstractSorter aSorter; 
		aSorter = null;
		int x = 0;
		int y = 0;
		
		//if else statements to assign aSorter with correct sorting algorithm
		if (sortingAlgorithm == Algorithm.SelectionSort) {
			aSorter = new SelectionSorter(points);
		}
		
		else if (sortingAlgorithm == Algorithm.InsertionSort) {
			aSorter = new InsertionSorter(points);
		}
		
		else if (sortingAlgorithm == Algorithm.MergeSort) {
			aSorter = new MergeSorter(points);
		}
		
		else if (sortingAlgorithm == Algorithm.QuickSort) {
			aSorter = new QuickSorter(points);
		}
		
		//setComparator to 0 which will compare x values
		aSorter.setComparator(0);
		//get time before sorting
		long before = System.nanoTime();
		//sort based on which algorithm was chosen previously
		aSorter.sort();
		//get time after sorting
		long after = System.nanoTime();
		//set local x value to median of the sorted array
		x = aSorter.getMedian().getX();
		
		//get the difference of time between after the sorting and before to find time spent sorting
		long xTime = after - before;
		
		//same as before but with comparator set to 1 its getting the y value
		aSorter.setComparator(1);
		before = System.nanoTime();
		aSorter.sort();
		after = System.nanoTime();
		y = aSorter.getMedian().getY();
		
		long yTime = after - before;
		
		//sum the time sorting the x and y values
		long totalTime = xTime + yTime;
		
		//set medianCoordinatePoint to the x and y values we got
		medianCoordinatePoint = new Point(x,y);
		//set scanTime to the time we got
		scanTime = totalTime;
		
		// create an object to be referenced by aSorter according to sortingAlgorithm. for each of the two 
		// rounds of sorting, have aSorter do the following: 
		// 
		//     a) call setComparator() with an argument 0 or 1. 
		//
		//     b) call sort(). 		
		// 
		//     c) use a new Point object to store the coordinates of the medianCoordinatePoint
		//
		//     d) set the medianCoordinatePoint reference to the object with the correct coordinates.
		//
		//     e) sum up the times spent on the two sorting rounds and set the instance variable scanTime. 
		
	}
	
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the project description. 
	 */
	public String stats()
	{
		//print the algorithm, number of points, and time took sorting
		//if else statement is used for formatting since two of the algorithm names are longer than the other two
		if (sortingAlgorithm == Algorithm.InsertionSort || sortingAlgorithm == Algorithm.SelectionSort) {
			return sortingAlgorithm.toString() + " " + points.length + " " + scanTime;
		}
		
		else {
			return sortingAlgorithm.toString() + "     " + points.length + " " + scanTime;
		}
	}
	
	
	/**
	 * Write MCP after a call to scan(),  in the format "MCP: (x, y)"   The x and y coordinates of the point are displayed on the same line with exactly one blank space 
	 * in between. 
	 */
	@Override
	public String toString()
	{
		return "MCP: (" + medianCoordinatePoint.getX() + ", " + medianCoordinatePoint.getY() + ")"; 
	}

	
	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName. The format 
	 * of data in the file is the same as printed out from toString().  The file can help you verify 
	 * the full correctness of a sorting result and debug the underlying algorithm. 
	 * 
	 * @throws FileNotFoundException
	 */
	public void writeMCPToFile() throws FileNotFoundException
	{
		//outputs the MCP to a file named outputFileName, no String is passed in the function so filename can't be specified
		try {
			FileWriter output = new FileWriter("outputFileName.txt");
			output.write(toString());
			output.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}	

	

		
}
